import numpy as np
import pandas as pd
import pytest

from src.predictor.config import Config
from src.predictor.data import DataManager
from src.predictor.predictor import Predictor
from src.predictor.trainer import ModelTrainer


# ── Helpers ───────────────────────────────────────────────────────────────────

def _build_predictor(n=60, con_empate=True):
    """Return a fully trained (cfg, trainer, data_mgr, predictor) tuple."""
    rng = np.random.default_rng(7)
    cfg = Config()
    cfg.feat_names_A  = ["goles", "posesion"]
    cfg.feat_names_B  = ["goles", "posesion"]
    cfg.con_empate    = con_empate
    cfg.n_iter_search = 3
    cfg.cv_folds      = 3

    df = pd.DataFrame({
        "A_goles":    rng.uniform(0, 3, n),
        "A_posesion": rng.uniform(40, 60, n),
        "B_goles":    rng.uniform(0, 3, n),
        "B_posesion": rng.uniform(40, 60, n),
        "resultado":  (["A", "B", "E"] * (n // 3 + 1))[:n] if con_empate
                      else (["A", "B"] * (n // 2 + 1))[:n],
    })

    dm = DataManager(cfg)
    dm.preparar(df)
    X = dm.get_X()
    y = dm.get_y_class()

    trainer = ModelTrainer(cfg)
    trainer.entrenar_clasificador(X, y)

    pred = Predictor(cfg, trainer, dm)
    return cfg, trainer, dm, pred


_STATS_A = {"goles": 2.0, "posesion": 55.0}
_STATS_B = {"goles": 1.0, "posesion": 45.0}


# ── predecir ──────────────────────────────────────────────────────────────────

def test_predecir_returns_ganador_key():
    _, _, _, pred = _build_predictor()
    res = pred.predecir(_STATS_A, _STATS_B, verbose=False)
    assert "ganador" in res


def test_predecir_ganador_is_valid_label(capsys):
    cfg, _, _, pred = _build_predictor()
    res = pred.predecir(_STATS_A, _STATS_B, verbose=False)
    opciones = {cfg.nombre_A, cfg.nombre_B, "Empate"}
    assert res["ganador"] in opciones


def test_predecir_probabilidades_sum_to_one():
    _, _, _, pred = _build_predictor()
    res = pred.predecir(_STATS_A, _STATS_B, verbose=False)
    total = sum(res["probabilidades"].values())
    assert abs(total - 1.0) < 1e-6


def test_predecir_probabilidades_all_non_negative():
    _, _, _, pred = _build_predictor()
    res = pred.predecir(_STATS_A, _STATS_B, verbose=False)
    assert all(v >= 0 for v in res["probabilidades"].values())


def test_predecir_no_empate_classes():
    _, _, _, pred = _build_predictor(con_empate=False)
    res = pred.predecir(_STATS_A, _STATS_B, verbose=False)
    assert "Empate" not in res["probabilidades"]


def test_predecir_with_regressors():
    cfg, trainer, dm, pred = _build_predictor(n=60)
    rng = np.random.default_rng(0)
    X   = dm.get_X()
    y_A = pd.Series(rng.uniform(0, 4, len(X)))
    y_B = pd.Series(rng.uniform(0, 4, len(X)))
    trainer.entrenar_regresores(X, y_A, y_B)

    res = pred.predecir(_STATS_A, _STATS_B, verbose=False)
    assert "puntuacion_A" in res
    assert "puntuacion_B" in res
    assert isinstance(res["puntuacion_A"], float)


def test_predecir_verbose_prints_output(capsys):
    _, _, _, pred = _build_predictor()
    pred.predecir(_STATS_A, _STATS_B, verbose=True)
    out = capsys.readouterr().out
    assert "Probabilidad" in out or "%" in out
