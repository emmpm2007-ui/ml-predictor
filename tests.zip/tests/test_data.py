import numpy as np
import pandas as pd
import pytest

from src.predictor.config import Config
from src.predictor.data import DataManager


# ── Helpers ───────────────────────────────────────────────────────────────────

def _cfg(feats=None, con_empate=True, score_A=None, score_B=None):
    cfg = Config()
    cfg.feat_names_A = feats or ["goles", "posesion"]
    cfg.feat_names_B = feats or ["goles", "posesion"]
    cfg.con_empate   = con_empate
    cfg.score_col_A  = score_A
    cfg.score_col_B  = score_B
    return cfg


def _df(n=20, con_empate=True, score=False):
    rng = np.random.default_rng(0)
    df  = pd.DataFrame({
        "A_goles":    rng.uniform(0, 3, n),
        "A_posesion": rng.uniform(40, 60, n),
        "B_goles":    rng.uniform(0, 3, n),
        "B_posesion": rng.uniform(40, 60, n),
        "resultado":  (["A", "B", "E"] * (n // 3 + 1))[:n] if con_empate
                      else (["A", "B"] * (n // 2 + 1))[:n],
    })
    if score:
        df["score_A"] = rng.uniform(0, 4, n)
        df["score_B"] = rng.uniform(0, 4, n)
    return df


# ── cargar_csv ────────────────────────────────────────────────────────────────

def test_cargar_csv_comma(tmp_path):
    df = _df()
    path = tmp_path / "data.csv"
    df.to_csv(path, index=False, sep=",")
    dm = DataManager(_cfg())
    loaded = dm.cargar_csv(str(path))
    assert len(loaded) == len(df)
    assert "A_goles" in loaded.columns


def test_cargar_csv_semicolon(tmp_path):
    df = _df()
    path = tmp_path / "data.csv"
    df.to_csv(path, index=False, sep=";")
    dm = DataManager(_cfg())
    loaded = dm.cargar_csv(str(path))
    assert len(loaded) > 0


def test_cargar_csv_not_found():
    dm = DataManager(_cfg())
    with pytest.raises(FileNotFoundError):
        dm.cargar_csv("/ruta/que/no/existe.csv")


# ── preparar ──────────────────────────────────────────────────────────────────

def test_preparar_builds_feature_cols():
    dm = DataManager(_cfg())
    dm.preparar(_df())
    assert len(dm.feature_cols) > 0
    assert "A_goles" in dm.feature_cols


def test_preparar_creates_diff_and_ratio():
    dm = DataManager(_cfg())
    dm.preparar(_df())
    assert any(c.startswith("DIFF_") for c in dm.feature_cols)
    assert any(c.startswith("RATIO_") for c in dm.feature_cols)


def test_preparar_raises_on_missing_columns():
    cfg = _cfg(feats=["columna_inexistente"])
    dm  = DataManager(cfg)
    with pytest.raises(ValueError, match="no encontradas"):
        dm.preparar(_df())


def test_preparar_imputes_nulls():
    df  = _df()
    df.loc[0, "A_goles"] = np.nan
    dm  = DataManager(_cfg())
    dm.preparar(df)
    assert not dm.df["A_goles"].isnull().any()


# ── get_X / get_y_class ───────────────────────────────────────────────────────

def test_get_X_shape():
    dm = DataManager(_cfg())
    dm.preparar(_df(n=20))
    X  = dm.get_X()
    assert X.shape[0] == 20
    assert X.shape[1] == len(dm.feature_cols)


def test_get_y_class_values():
    dm = DataManager(_cfg())
    dm.preparar(_df(n=30))
    y  = dm.get_y_class()
    assert set(y.unique()).issubset({0, 1, 2})


def test_get_y_class_no_empate():
    cfg = _cfg(con_empate=False)
    cfg.con_empate = False
    dm  = DataManager(cfg)
    dm.preparar(_df(n=20, con_empate=False))
    y   = dm.get_y_class()
    assert 2 not in y.values


# ── get_pesos ─────────────────────────────────────────────────────────────────

def test_get_pesos_none_by_default():
    dm = DataManager(_cfg())
    dm.preparar(_df())
    assert dm.get_pesos() is None


def test_get_pesos_returns_array_when_enabled():
    cfg = _cfg()
    cfg.usar_pesos_temporales = True
    dm  = DataManager(cfg)
    dm.preparar(_df(n=20))
    pesos = dm.get_pesos()
    assert pesos is not None
    assert len(pesos) == 20
    assert pesos[-1] > pesos[0]          # recent matches weight more


# ── construir_vector_prediccion ───────────────────────────────────────────────

def test_construir_vector_prediccion_shape():
    dm = DataManager(_cfg())
    dm.preparar(_df(n=20))
    row = dm.construir_vector_prediccion(
        {"goles": 1.5, "posesion": 52.0},
        {"goles": 1.0, "posesion": 48.0},
    )
    assert row.shape == (1, len(dm.feature_cols))


def test_construir_vector_prediccion_diff_values():
    dm = DataManager(_cfg())
    dm.preparar(_df(n=20))
    row = dm.construir_vector_prediccion(
        {"goles": 2.0, "posesion": 55.0},
        {"goles": 1.0, "posesion": 45.0},
    )
    assert row["DIFF_goles"].iloc[0] == pytest.approx(1.0)
