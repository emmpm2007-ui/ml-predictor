import json
import pytest
from src.predictor.config import Config


def test_default_values():
    cfg = Config()
    assert cfg.deporte == "futbol"
    assert cfg.con_empate is True
    assert cfg.feat_names_A == []
    assert cfg.cv_folds == 5


def test_to_dict_is_plain_dict():
    cfg = Config()
    d = cfg.to_dict()
    assert isinstance(d, dict)
    assert "deporte" in d
    assert "feat_names_A" in d


def test_from_dict_round_trip():
    cfg = Config()
    cfg.deporte = "combat"
    cfg.feat_names_A = ["victorias", "derrotas"]
    cfg.cv_folds = 3

    cfg2 = Config.from_dict(cfg.to_dict())
    assert cfg2.deporte == "combat"
    assert cfg2.feat_names_A == ["victorias", "derrotas"]
    assert cfg2.cv_folds == 3


def test_from_dict_ignores_unknown_keys():
    cfg = Config.from_dict({"deporte": "mma", "campo_inexistente": 99})
    assert cfg.deporte == "mma"
    assert not hasattr(cfg, "campo_inexistente")


def test_save_and_load(tmp_path):
    cfg = Config()
    cfg.deporte = "combat"
    cfg.nombre_A = "Fighter A"
    cfg.feat_names_A = ["victorias", "alcance_cm"]
    path = str(tmp_path / "config.json")

    cfg.save(path)
    assert (tmp_path / "config.json").exists()

    cfg2 = Config.load(path)
    assert cfg2.deporte == "combat"
    assert cfg2.nombre_A == "Fighter A"
    assert cfg2.feat_names_A == ["victorias", "alcance_cm"]


def test_saved_file_is_valid_json(tmp_path):
    cfg = Config()
    path = str(tmp_path / "cfg.json")
    cfg.save(path)
    with open(path) as f:
        data = json.load(f)
    assert "deporte" in data
