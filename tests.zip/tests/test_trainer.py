import numpy as np
import pandas as pd
import pytest

from src.predictor.config import Config
from src.predictor.data import DataManager
from src.predictor.trainer import ModelTrainer


# ── Helpers ───────────────────────────────────────────────────────────────────

def _make_Xy(n=60, con_empate=True):
    rng = np.random.default_rng(42)
    cfg = Config()
    cfg.feat_names_A = ["goles", "posesion"]
    cfg.feat_names_B = ["goles", "posesion"]
    cfg.con_empate   = con_empate
    cfg.n_iter_search = 3     # fast search for tests
    cfg.cv_folds      = 3

    df = pd.DataFrame({
        "A_goles":    rng.uniform(0, 3, n),
        "A_posesion": rng.uniform(40, 60, n),
        "B_goles":    rng.uniform(0, 3, n),
        "B_posesion": rng.uniform(40, 60, n),
        "resultado":  (["A", "B", "E"] * (n // 3 + 1))[:n] if con_empate
                      else (["A", "B"] * (n // 2 + 1))[:n],
    })
    dm = DataManager(cfg)
    dm.preparar(df)
    X = dm.get_X()
    y = dm.get_y_class()
    return cfg, dm, X, y


# ── Classifier ────────────────────────────────────────────────────────────────

def test_entrenar_clasificador_sets_best_clf():
    cfg, dm, X, y = _make_Xy()
    trainer = ModelTrainer(cfg)
    trainer.entrenar_clasificador(X, y)
    assert trainer.best_clf is not None


def test_clf_report_has_expected_keys():
    cfg, dm, X, y = _make_Xy()
    trainer = ModelTrainer(cfg)
    trainer.entrenar_clasificador(X, y)
    for key in ("cv_accuracy_mean", "cv_f1_mean", "mejor_modelo"):
        assert key in trainer.clf_report


def test_class_values_correct_with_empate():
    cfg, dm, X, y = _make_Xy(con_empate=True)
    trainer = ModelTrainer(cfg)
    trainer.entrenar_clasificador(X, y)
    assert 2 in trainer.class_values     # empate encoded as 2


def test_class_values_correct_without_empate():
    cfg, dm, X, y = _make_Xy(con_empate=False, n=60)
    trainer = ModelTrainer(cfg)
    trainer.entrenar_clasificador(X, y)
    assert 2 not in trainer.class_values


def test_feature_cols_stored():
    cfg, dm, X, y = _make_Xy()
    trainer = ModelTrainer(cfg)
    trainer.entrenar_clasificador(X, y)
    assert len(trainer.feature_cols) == X.shape[1]


def test_predict_after_train():
    cfg, dm, X, y = _make_Xy()
    trainer = ModelTrainer(cfg)
    trainer.entrenar_clasificador(X, y)
    preds = trainer.best_clf.predict(X)
    assert len(preds) == len(y)


# ── Regressors ────────────────────────────────────────────────────────────────

def test_entrenar_regresores_sets_best_reg():
    cfg, dm, X, y = _make_Xy(n=60)
    rng = np.random.default_rng(0)
    y_A = pd.Series(rng.uniform(0, 4, len(X)), name="score_A")
    y_B = pd.Series(rng.uniform(0, 4, len(X)), name="score_B")

    trainer = ModelTrainer(cfg)
    trainer.entrenar_clasificador(X, y)
    trainer.entrenar_regresores(X, y_A, y_B)

    assert trainer.best_reg_A is not None
    assert trainer.best_reg_B is not None


def test_entrenar_regresores_none_skips():
    cfg, dm, X, y = _make_Xy()
    trainer = ModelTrainer(cfg)
    trainer.entrenar_clasificador(X, y)
    trainer.entrenar_regresores(X, None, None)
    assert trainer.best_reg_A is None
    assert trainer.best_reg_B is None


# ── Candidates ────────────────────────────────────────────────────────────────

def test_clasificadores_candidatos_includes_base_models():
    cfg = Config()
    trainer = ModelTrainer(cfg)
    cands = trainer._clasificadores_candidatos()
    assert "RandomForest" in cands
    assert "GradientBoosting" in cands
    assert "MLP" in cands
