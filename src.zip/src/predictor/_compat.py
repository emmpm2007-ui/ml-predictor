"""
_compat.py — Optional dependency detection.

Import this module to check which performance-boosting packages are available
at runtime.  All flags are booleans; the corresponding classes are ``None``
when the package is not installed so callers can guard with ``if XGBOOST_OK``.
"""

from __future__ import annotations

# ── XGBoost ────────────────────────────────────────────────────────────────────

try:
    from xgboost import XGBClassifier, XGBRegressor   # type: ignore[import]
    XGBOOST_OK = True
except ImportError:
    XGBClassifier = None   # type: ignore[assignment, misc]
    XGBRegressor  = None   # type: ignore[assignment, misc]
    XGBOOST_OK    = False

# ── LightGBM ───────────────────────────────────────────────────────────────────

try:
    from lightgbm import LGBMClassifier, LGBMRegressor   # type: ignore[import]
    LIGHTGBM_OK = True
except ImportError:
    LGBMClassifier = None   # type: ignore[assignment, misc]
    LGBMRegressor  = None   # type: ignore[assignment, misc]
    LIGHTGBM_OK    = False

# ── SHAP ───────────────────────────────────────────────────────────────────────

try:
    import shap as _shap   # type: ignore[import]
    shap    = _shap
    SHAP_OK = True
except ImportError:
    shap    = None   # type: ignore[assignment]
    SHAP_OK = False
