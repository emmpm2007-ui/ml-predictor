"""
ui.py — Terminal UI utilities.

Thin wrappers around ANSI colour codes and stdin/stdout for a consistent
console experience throughout the predictor.
"""

from __future__ import annotations

from typing import Any

from .constants import COLORES


# ── Colour and formatting ──────────────────────────────────────────────────────

def c(texto: str, color: str) -> str:
    """Wrap *texto* with the ANSI escape code for *color*.

    Args:
        texto: Text to colorize.
        color: Key in :data:`~predictor.constants.COLORES`.

    Returns:
        The text surrounded by the colour start/reset codes.
    """
    return f"{COLORES.get(color, '')}{texto}{COLORES['reset']}"


def titulo(texto: str, ancho: int = 62) -> None:
    """Print a framed section title."""
    linea = "═" * ancho
    print(f"\n{c(linea, 'titulo')}")
    print(c(f"  {texto}", "bold"))
    print(c(linea, "titulo"))


def info(msg: str) -> None:
    """Print an informational message (blue ℹ)."""
    print(f"  {c('ℹ', 'titulo')} {msg}")


def ok(msg: str) -> None:
    """Print a success message (green ✔)."""
    print(f"  {c('✔', 'ok')} {msg}")


def warn(msg: str) -> None:
    """Print a warning message (yellow ⚠)."""
    print(f"  {c('⚠', 'warn')} {msg}")


def error(msg: str) -> None:
    """Print an error message (red ✖)."""
    print(f"  {c('✖', 'error')} {msg}")


def separador() -> None:
    """Print a dim horizontal rule."""
    print(f"  {c('─' * 58, 'dim')}")


# ── Input helpers ──────────────────────────────────────────────────────────────

def pedir(
    prompt: str,
    tipo: type = str,
    opciones: list | None = None,
    default: Any = None,
    allow_blank: bool = False,
) -> Any:
    """Ask the user for a validated value.

    Args:
        prompt:      Text shown before the cursor.
        tipo:        Expected Python type (``str``, ``int``, ``float``).
        opciones:    If given, the answer must be one of these values.
        default:     Returned when the user presses Enter with no input.
        allow_blank: Allow an empty string answer.

    Returns:
        The validated value cast to *tipo*.
    """
    sufijo = ""
    if default is not None:
        sufijo = f" [{c(str(default), 'dim')}]"
    if opciones:
        sufijo += f" ({'/'.join(str(o) for o in opciones)})"

    while True:
        try:
            raw = input(f"  {prompt}{sufijo}: ").strip()
        except (KeyboardInterrupt, EOFError):
            raise

        if raw == "" and default is not None:
            return default
        if raw == "" and allow_blank:
            return ""
        if raw == "":
            warn("No puedes dejar esto vacío.")
            continue

        try:
            valor = tipo(raw) if tipo is not str else raw
        except (ValueError, TypeError):
            error(f"Se esperaba un valor de tipo {tipo.__name__}. Inténtalo de nuevo.")
            continue

        if opciones and valor not in opciones:
            warn(f"Valor inválido. Elige entre: {', '.join(str(o) for o in opciones)}")
            continue

        return valor


def confirmar(prompt: str, default: bool = True) -> bool:
    """Ask a yes/no question.

    Args:
        prompt:  Question text.
        default: Returned when the user presses Enter.

    Returns:
        ``True`` for yes, ``False`` for no.
    """
    default_str = "S/n" if default else "s/N"
    raw = input(f"  {prompt} [{default_str}]: ").strip().lower()
    if raw == "":
        return default
    return raw in ("s", "si", "sí", "yes", "y")
