"""
constants.py — Global constants for the sports match predictor.

Contains feature suggestions per sport, CSV separator candidates,
ANSI terminal colour codes, and the automatic-mode path overrides.
"""

from __future__ import annotations

# ── Feature suggestions per sport ─────────────────────────────────────────────

SUGERENCIAS: dict[str, list[str]] = {
    "futbol": [
        "goles_esperados_partido", "goles_encajados_partido", "posesion_pct",
        "tiros_puerta_partido", "precision_pase_pct", "corners_partido",
        "faltas_partido", "efectividad_disparos_pct", "victorias_ultimos5",
        "goles_ultimos5", "puntos_partido_local", "diferencia_goles",
        "valor_mercado_M_eur", "lesiones_titulares", "dias_descanso",
        "historial_rival",
    ],
    "combat": [
        "victorias_total", "derrotas_total", "pct_ko_tko", "altura_cm",
        "alcance_cm", "golpes_significativos_por_min", "efectividad_derribos_pct",
        "defensa_derribos_pct", "tiempo_pelea_promedio_min", "edad",
        "racha_victorias", "nivel_striking_1_10", "nivel_grappling_1_10",
        "cardio_1_10", "combates_ultimo_anio",
    ],
}

# ── CSV auto-detection ─────────────────────────────────────────────────────────

SEPARADORES_CSV: list[str] = [",", ";", "\t", "|"]

# ── ANSI terminal colour codes ─────────────────────────────────────────────────

COLORES: dict[str, str] = {
    "titulo": "\033[96m",
    "ok":     "\033[92m",
    "warn":   "\033[93m",
    "error":  "\033[91m",
    "reset":  "\033[0m",
    "bold":   "\033[1m",
    "dim":    "\033[2m",
}

# ── Automatic mode (edit here to skip interactive prompts) ─────────────────────
# Set AUTO_CSV_PATH to a real file path to enable headless mode on startup.

AUTO_CSV_PATH: str    = "dataset_mma.csv"
AUTO_CONFIG_PATH: str = "config_mma.json"
