"""
visualizer.py — Diagnostic plots saved to ``reporte_predictor/``.

``Visualizador``
    Generates a confusion matrix, feature-importance bar chart, regressor
    diagnostics (real-vs-predicted and residual histograms), and optionally
    a SHAP summary plot.  All figures are saved to disk; nothing is displayed
    interactively (``Agg`` backend).
"""

from __future__ import annotations

from pathlib import Path

import matplotlib
matplotlib.use("Agg")          # headless — save to disk, no display window
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from sklearn.metrics import ConfusionMatrixDisplay, confusion_matrix

from .config import Config
from .trainer import ModelTrainer
from .ui import info, ok, warn
from ._compat import SHAP_OK, shap


class Visualizador:
    """Generate and save diagnostic plots for a trained predictor.

    Args:
        cfg:     Bound :class:`~predictor.config.Config`.
        trainer: Trained :class:`~predictor.trainer.ModelTrainer`.

    Attributes:
        output_dir: :class:`pathlib.Path` where plots are saved
                    (``reporte_predictor/`` by default, created automatically).
    """

    def __init__(self, cfg: Config, trainer: ModelTrainer) -> None:
        self.cfg        = cfg
        self.trainer    = trainer
        self.output_dir = Path("reporte_predictor")
        self.output_dir.mkdir(exist_ok=True)

    # ── Public API ─────────────────────────────────────────────────────────────

    def graficar_todo(
        self,
        X:   pd.DataFrame,
        y:   pd.Series,
        y_A: pd.Series | None = None,
        y_B: pd.Series | None = None,
    ) -> None:
        """Generate and save all applicable diagnostic plots.

        Args:
            X:   Feature matrix used for training.
            y:   Classification target.
            y_A: Numeric score series for A (when regressors were trained).
            y_B: Numeric score series for B (when regressors were trained).
        """
        info("Generando gráficos de diagnóstico...")

        for nombre, fn in [
            ("matriz de confusión",         lambda: self._confusion_matrix(X, y)),
            ("importancia de features",     lambda: self._feature_importance(X)),
        ]:
            try:
                fn()
            except Exception as exc:
                warn(f"No se pudo generar {nombre}: {exc}")

        if y_A is not None and self.trainer.best_reg_A:
            try:
                self._regresion_diagnostico(X, y_A, self.trainer.best_reg_A, self.cfg.nombre_A)
            except Exception as exc:
                warn(f"Diagnóstico regresor A fallido: {exc}")

        if y_B is not None and self.trainer.best_reg_B:
            try:
                self._regresion_diagnostico(X, y_B, self.trainer.best_reg_B, self.cfg.nombre_B)
            except Exception as exc:
                warn(f"Diagnóstico regresor B fallido: {exc}")

        if SHAP_OK and self.trainer.best_clf is not None:
            try:
                self._shap_summary(X)
            except Exception as exc:
                warn(f"SHAP no disponible para este modelo: {exc}")

        ok(f"Gráficos guardados en '{self.output_dir}/'")

    # ── Private helpers ────────────────────────────────────────────────────────

    def _confusion_matrix(self, X: pd.DataFrame, y: pd.Series) -> None:
        clf    = self.trainer.best_clf
        y_pred = clf.predict(X)

        fig, axes = plt.subplots(1, 2, figsize=(12, 5))
        for ax, normalize in zip(axes, [None, "true"]):
            cm   = confusion_matrix(y, y_pred, normalize=normalize)
            disp = ConfusionMatrixDisplay(
                confusion_matrix=cm,
                display_labels=self.trainer.label_names,
            )
            disp.plot(ax=ax, colorbar=False, cmap="Blues")
            ax.set_title(
                "Matriz de Confusión" + (" (normalizada)" if normalize else ""),
                fontsize=11, pad=10,
            )

        plt.tight_layout()
        plt.savefig(self.output_dir / "confusion_matrix.png", dpi=120, bbox_inches="tight")
        plt.close()

    def _feature_importance(self, X: pd.DataFrame) -> None:
        clf = self.trainer.best_clf
        if not hasattr(clf, "feature_importances_"):
            return

        importances = clf.feature_importances_
        indices     = np.argsort(importances)[::-1][:20]   # top-20
        top_feats   = [X.columns[i] for i in indices]
        top_vals    = importances[indices]

        plt.figure(figsize=(10, 6))
        palette = sns.color_palette("viridis", len(top_feats))
        plt.barh(top_feats[::-1], top_vals[::-1], color=palette[::-1])
        plt.xlabel("Importancia")
        plt.title("Top-20 Características más Importantes (Clasificador)", fontsize=12)
        plt.tight_layout()
        plt.savefig(self.output_dir / "feature_importance.png", dpi=120, bbox_inches="tight")
        plt.close()

    def _regresion_diagnostico(
        self,
        X:      pd.DataFrame,
        y:      pd.Series,
        modelo,
        nombre: str,
    ) -> None:
        y_pred   = modelo.predict(X)
        residuos = y.values - y_pred

        fig, axes = plt.subplots(1, 2, figsize=(12, 5))

        # Real vs predicted
        lims = [min(y.min(), y_pred.min()), max(y.max(), y_pred.max())]
        axes[0].scatter(y.values, y_pred, alpha=0.5, edgecolors="k", linewidths=0.3)
        axes[0].plot(lims, lims, "r--", linewidth=1)
        axes[0].set_xlabel("Real")
        axes[0].set_ylabel("Predicho")
        axes[0].set_title(f"Real vs Predicho — {nombre}")

        # Residual distribution
        axes[1].hist(residuos, bins=20, color="steelblue", edgecolor="white")
        axes[1].axvline(0, color="red", linestyle="--")
        axes[1].set_xlabel("Residuo")
        axes[1].set_title(f"Distribución de Residuos — {nombre}")

        plt.tight_layout()
        safe = nombre.replace(" ", "_")
        plt.savefig(self.output_dir / f"regresion_{safe}.png", dpi=120, bbox_inches="tight")
        plt.close()

    def _shap_summary(self, X: pd.DataFrame) -> None:
        n          = min(200, len(X))
        explainer  = shap.TreeExplainer(self.trainer.best_clf)
        shap_vals  = explainer.shap_values(X[:n])
        plt.figure(figsize=(10, 7))
        shap.summary_plot(shap_vals, X[:n], show=False)
        plt.tight_layout()
        plt.savefig(self.output_dir / "shap_summary.png", dpi=120, bbox_inches="tight")
        plt.close()
