"""
trainer.py — Model training and hyperparameter search.

``ModelTrainer``
    Selects the best classifier via ``RandomizedSearchCV`` with
    ``StratifiedKFold``, evaluates it with ``cross_validate``, optionally
    trains score regressors, and emits personalised tips.
"""

from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.ensemble import (
    GradientBoostingClassifier,
    GradientBoostingRegressor,
    RandomForestClassifier,
    RandomForestRegressor,
)
from sklearn.model_selection import RandomizedSearchCV, StratifiedKFold, cross_validate
from sklearn.neural_network import MLPClassifier

from .config import Config
from .ui import c, info, ok, titulo, warn
from ._compat import (
    LIGHTGBM_OK, SHAP_OK, XGBOOST_OK,
    LGBMClassifier, LGBMRegressor,
    XGBClassifier, XGBRegressor,
)


class ModelTrainer:
    """Train, select, and evaluate prediction models.

    Attributes:
        cfg:          Bound :class:`~predictor.config.Config`.
        best_clf:     Best-scoring classifier after hyperparameter search.
        best_reg_A:   Best regressor for competitor A's score (or ``None``).
        best_reg_B:   Best regressor for competitor B's score (or ``None``).
        clf_report:   Dict with CV accuracy and F1-macro means/stds.
        reg_report:   Dict with per-competitor R² and MAE.
        feature_cols: Ordered list of feature names seen during training.
        label_names:  Human-readable class labels in ``class_values`` order.
        class_values: Sorted list of integer target values.
    """

    def __init__(self, cfg: Config) -> None:
        self.cfg           = cfg
        self.best_clf      = None
        self.best_reg_A    = None
        self.best_reg_B    = None
        self.clf_report:   dict = {}
        self.reg_report:   dict = {}
        self.feature_cols: list[str] = []
        self.label_names:  list[str] = []
        self.class_values: list[int] = []

    # ── Candidate model builders ───────────────────────────────────────────────

    def _clasificadores_candidatos(self) -> dict[str, tuple]:
        """Return ``{name: (estimator, param_grid)}`` for all classifiers."""
        candidatos: dict[str, tuple] = {}

        candidatos["RandomForest"] = (
            RandomForestClassifier(class_weight="balanced", random_state=42),
            {
                "n_estimators":    [100, 200, 400],
                "max_depth":       [4, 6, 8, None],
                "min_samples_leaf": [1, 2, 5],
                "max_features":    ["sqrt", "log2"],
            },
        )
        candidatos["GradientBoosting"] = (
            GradientBoostingClassifier(random_state=42),
            {
                "n_estimators":   [100, 200],
                "max_depth":      [3, 5],
                "learning_rate":  [0.05, 0.1, 0.2],
                "subsample":      [0.8, 1.0],
            },
        )
        candidatos["MLP"] = (
            MLPClassifier(max_iter=500, random_state=42, early_stopping=True),
            {
                "hidden_layer_sizes": [(64,), (128, 64), (64, 32, 16)],
                "alpha":              [1e-4, 1e-3, 1e-2],
                "learning_rate_init": [0.001, 0.01],
            },
        )
        if XGBOOST_OK:
            candidatos["XGBoost"] = (
                XGBClassifier(
                    eval_metric="mlogloss",
                    use_label_encoder=False,
                    random_state=42,
                    verbosity=0,
                ),
                {
                    "n_estimators":     [100, 200, 300],
                    "max_depth":        [3, 5, 7],
                    "learning_rate":    [0.05, 0.1, 0.2],
                    "subsample":        [0.8, 1.0],
                    "colsample_bytree": [0.8, 1.0],
                },
            )
        if LIGHTGBM_OK:
            candidatos["LightGBM"] = (
                LGBMClassifier(random_state=42, verbose=-1),
                {
                    "n_estimators":  [100, 200, 300],
                    "max_depth":     [-1, 5, 10],
                    "num_leaves":    [31, 63, 127],
                    "learning_rate": [0.05, 0.1, 0.2],
                },
            )
        return candidatos

    def _regresores_candidatos(self) -> dict[str, tuple]:
        """Return ``{name: (estimator, param_grid)}`` for all regressors."""
        candidatos: dict[str, tuple] = {}

        candidatos["RandomForest"] = (
            RandomForestRegressor(random_state=42),
            {
                "n_estimators":    [100, 200, 300],
                "max_depth":       [4, 6, 8, None],
                "min_samples_leaf": [1, 2, 5],
            },
        )
        candidatos["GradientBoosting"] = (
            GradientBoostingRegressor(random_state=42),
            {
                "n_estimators":  [100, 200],
                "max_depth":     [3, 5],
                "learning_rate": [0.05, 0.1, 0.2],
            },
        )
        if XGBOOST_OK:
            candidatos["XGBoost"] = (
                XGBRegressor(random_state=42, verbosity=0),
                {
                    "n_estimators":  [100, 200],
                    "max_depth":     [3, 5],
                    "learning_rate": [0.05, 0.1],
                },
            )
        if LIGHTGBM_OK:
            candidatos["LightGBM"] = (
                LGBMRegressor(random_state=42, verbose=-1),
                {
                    "n_estimators":  [100, 200],
                    "max_depth":     [-1, 5],
                    "learning_rate": [0.05, 0.1],
                },
            )
        return candidatos

    # ── Classifier training ────────────────────────────────────────────────────

    def entrenar_clasificador(
        self,
        X: pd.DataFrame,
        y: pd.Series,
        sample_weight: np.ndarray | None = None,
    ) -> None:
        """Select and train the best classifier.

        Uses ``RandomizedSearchCV`` with ``StratifiedKFold`` to compare all
        candidates by ``f1_macro``, then runs a full ``cross_validate`` on
        the winner and re-trains it on the entire dataset.

        Args:
            X:             Feature matrix.
            y:             Integer classification target.
            sample_weight: Optional per-sample weights (temporal weighting).
        """
        titulo("BÚSQUEDA DE MEJOR CLASIFICADOR")
        cfg               = self.cfg
        self.feature_cols = list(X.columns)
        self.class_values = sorted(y.unique().tolist())

        inv_map: dict[int, str] = {1: cfg.nombre_A, 0: cfg.nombre_B}
        if cfg.con_empate:
            inv_map[2] = "Empate"
        self.label_names = [inv_map.get(v, str(v)) for v in self.class_values]

        skf          = StratifiedKFold(n_splits=cfg.cv_folds, shuffle=True, random_state=42)
        mejor_score  = -np.inf
        mejor_nombre = ""

        for nombre, (modelo, params) in self._clasificadores_candidatos().items():
            info(f"Probando {nombre}...")
            try:
                search = RandomizedSearchCV(
                    modelo, params,
                    n_iter=min(cfg.n_iter_search, 20),
                    cv=skf, scoring="f1_macro",
                    n_jobs=-1, random_state=42, refit=True,
                )
                fit_kwargs: dict = {}
                if sample_weight is not None and nombre != "MLP":
                    fit_kwargs["sample_weight"] = sample_weight
                search.fit(X, y, **fit_kwargs)
                score = search.best_score_
                info(f"  → F1-macro CV: {score:.4f}  (params: {search.best_params_})")
                if score > mejor_score:
                    mejor_score  = score
                    self.best_clf = search.best_estimator_
                    mejor_nombre  = nombre
            except Exception as exc:
                warn(f"  {nombre} falló: {exc}")

        ok(f"Mejor clasificador: {c(mejor_nombre, 'bold')} | F1-macro CV: {mejor_score:.4f}")

        # Full cross-validation report
        titulo("MÉTRICAS DE CLASIFICACIÓN (Validación Cruzada)")
        cv_results = cross_validate(
            self.best_clf, X, y, cv=skf,
            scoring=["accuracy", "f1_macro"],
            return_train_score=True, n_jobs=-1,
        )
        for metrica in ["accuracy", "f1_macro"]:
            tr = cv_results[f"train_{metrica}"]
            va = cv_results[f"test_{metrica}"]
            print(
                f"  {metrica:<12} │ "
                f"Train: {tr.mean():.3f} ±{tr.std():.3f} │ "
                f"Val:   {va.mean():.3f} ±{va.std():.3f}"
            )

        self.clf_report = {
            "cv_accuracy_mean": float(cv_results["test_accuracy"].mean()),
            "cv_accuracy_std":  float(cv_results["test_accuracy"].std()),
            "cv_f1_mean":       float(cv_results["test_f1_macro"].mean()),
            "cv_f1_std":        float(cv_results["test_f1_macro"].std()),
            "mejor_modelo":     mejor_nombre,
        }

        self.best_clf.fit(X, y)
        self._consejos_precision(X, y)

    # ── Regressor training ─────────────────────────────────────────────────────

    def _entrenar_un_regresor(
        self, X: pd.DataFrame, y: pd.Series, etiqueta: str
    ):
        """Select and train the best regressor for one score column."""
        cfg           = self.cfg
        mejor_neg_mse = -np.inf
        mejor_modelo  = None

        for nombre, (modelo, params) in self._regresores_candidatos().items():
            try:
                search = RandomizedSearchCV(
                    modelo, params,
                    n_iter=min(cfg.n_iter_search, 15),
                    cv=5, scoring="neg_mean_squared_error",
                    n_jobs=-1, random_state=42, refit=True,
                )
                search.fit(X, y)
                if search.best_score_ > mejor_neg_mse:
                    mejor_neg_mse = search.best_score_
                    mejor_modelo  = search.best_estimator_
            except Exception:
                pass

        if mejor_modelo:
            mejor_modelo.fit(X, y)
            ok(f"Regresor {etiqueta}: MSE-CV ≈ {-mejor_neg_mse:.4f}")
        return mejor_modelo

    def entrenar_regresores(
        self,
        X:   pd.DataFrame,
        y_A: pd.Series | None,
        y_B: pd.Series | None,
    ) -> None:
        """Train score regressors for A and/or B.

        Args:
            X:   Feature matrix.
            y_A: Numeric score series for competitor A, or ``None``.
            y_B: Numeric score series for competitor B, or ``None``.
        """
        titulo("ENTRENAMIENTO DE REGRESORES DE PUNTUACIÓN")
        cfg = self.cfg

        if y_A is not None:
            info(f"Regresor para {cfg.nombre_A}...")
            self.best_reg_A = self._entrenar_un_regresor(X, y_A, cfg.nombre_A)
            if self.best_reg_A:
                m = self._eval_regresor_cv(X, y_A, self.best_reg_A)
                print(f"  R² val: {m['r2']:.4f}  |  MAE val: {m['mae']:.4f}")
                self.reg_report["A"] = m

        if y_B is not None:
            info(f"Regresor para {cfg.nombre_B}...")
            self.best_reg_B = self._entrenar_un_regresor(X, y_B, cfg.nombre_B)
            if self.best_reg_B:
                m = self._eval_regresor_cv(X, y_B, self.best_reg_B)
                print(f"  R² val: {m['r2']:.4f}  |  MAE val: {m['mae']:.4f}")
                self.reg_report["B"] = m

    def _eval_regresor_cv(
        self, X: pd.DataFrame, y: pd.Series, modelo
    ) -> dict[str, float]:
        scores = cross_validate(
            modelo, X, y, cv=5,
            scoring=["r2", "neg_mean_absolute_error"],
            return_train_score=False, n_jobs=-1,
        )
        return {
            "r2":  float(scores["test_r2"].mean()),
            "mae": float(-scores["test_neg_mean_absolute_error"].mean()),
        }

    # ── Tips ───────────────────────────────────────────────────────────────────

    def _consejos_precision(self, X: pd.DataFrame, y: pd.Series) -> None:
        """Print data-driven tips to improve model performance."""
        titulo("CONSEJOS PARA MEJORAR LA PRECISIÓN")
        n    = len(X)
        acc  = self.clf_report.get("cv_accuracy_mean", 0)

        if n < 100:
            warn(f"Solo tienes {n} registros. Con menos de 100 la precisión es baja; "
                 "intenta conseguir al menos 200-500 enfrentamientos.")
        elif n < 500:
            info(f"Tienes {n} registros. Con 500+ la precisión mejora significativamente.")
        else:
            ok(f"Buen volumen de datos: {n} registros.")

        if len(X.columns) < 6:
            warn("Pocas características. Añadir rachas, head-to-head y estadísticas "
                 "defensivas suele mejorar mucho el modelo.")

        if acc < 0.55:
            warn(f"Accuracy CV: {acc:.1%}. El modelo apenas supera el azar. "
                 "Revisa la calidad y consistencia de los datos.")
        elif acc < 0.70:
            info(f"Accuracy CV: {acc:.1%}. Aceptable. Prueba a añadir más features o datos.")
        else:
            ok(f"Accuracy CV: {acc:.1%}. Buen resultado.")

        if not XGBOOST_OK:
            info("Instala xgboost ('pip install xgboost') para modelos más potentes.")
        if not LIGHTGBM_OK:
            info("Instala lightgbm ('pip install lightgbm') para mayor velocidad.")
        if not SHAP_OK:
            info("Instala shap ('pip install shap') para interpretabilidad avanzada.")
