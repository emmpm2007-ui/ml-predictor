"""
predictor.py — Match outcome prediction interface.

``Predictor``
    Builds the prediction vector, runs the classifier (and optional
    regressors), formats the result for the terminal, and provides an
    interactive prediction loop.
"""

from __future__ import annotations

from typing import Any

from .config import Config
from .data import DataManager
from .trainer import ModelTrainer
from .ui import c, confirmar, error, titulo


class Predictor:
    """Interactive prediction interface for a trained model.

    Args:
        cfg:      Bound :class:`~predictor.config.Config`.
        trainer:  Trained :class:`~predictor.trainer.ModelTrainer`.
        data_mgr: Prepared :class:`~predictor.data.DataManager` (needed for
                  :meth:`~DataManager.construir_vector_prediccion`).
    """

    def __init__(
        self,
        cfg:      Config,
        trainer:  ModelTrainer,
        data_mgr: DataManager,
    ) -> None:
        self.cfg      = cfg
        self.trainer  = trainer
        self.data_mgr = data_mgr

    # ── Input helpers ──────────────────────────────────────────────────────────

    def pedir_estadisticas(
        self, nombre: str, feats: list[str]
    ) -> dict[str, float]:
        """Interactively collect numeric stats for one competitor.

        Args:
            nombre: Display name shown in the prompt.
            feats:  List of feature names to collect.

        Returns:
            Mapping of feature name → float value.
        """
        print(f"\n  {c('► Estadísticas de ' + nombre, 'bold')}")
        stats: dict[str, float] = {}
        for feat in feats:
            while True:
                try:
                    stats[feat] = float(input(f"    {feat}: ").strip())
                    break
                except ValueError:
                    error("Introduce un número válido.")
        return stats

    # ── Prediction ─────────────────────────────────────────────────────────────

    def predecir(
        self,
        stats_A: dict[str, float] | None = None,
        stats_B: dict[str, float] | None = None,
        verbose: bool = True,
    ) -> dict[str, Any]:
        """Predict the outcome of one match.

        Args:
            stats_A: Stats for A; collected interactively when ``None``.
            stats_B: Stats for B; collected interactively when ``None``.
            verbose: Print a formatted result to stdout.

        Returns:
            Dictionary with keys ``ganador``, ``probabilidades``, and
            optionally ``puntuacion_A`` / ``puntuacion_B``.
        """
        cfg     = self.cfg
        trainer = self.trainer

        if stats_A is None:
            stats_A = self.pedir_estadisticas(cfg.nombre_A, cfg.feat_names_A)
        if stats_B is None:
            stats_B = self.pedir_estadisticas(cfg.nombre_B, cfg.feat_names_B)

        X_input = self.data_mgr.construir_vector_prediccion(stats_A, stats_B)

        clf     = trainer.best_clf
        proba   = clf.predict_proba(X_input)[0]
        pred_cls = clf.predict(X_input)[0]

        inv_map: dict[int, str] = {1: cfg.nombre_A, 0: cfg.nombre_B}
        if cfg.con_empate:
            inv_map[2] = "Empate"

        prob_legible: dict[str, float] = {
            cls_name: float(proba[list(clf.classes_).index(cls_val)])
            for cls_val, cls_name in inv_map.items()
            if cls_val in clf.classes_
        }
        ganador = inv_map.get(int(pred_cls), "?")

        resultado: dict[str, Any] = {
            "ganador":         ganador,
            "probabilidades":  prob_legible,
        }
        if trainer.best_reg_A:
            resultado["puntuacion_A"] = float(trainer.best_reg_A.predict(X_input)[0])
        if trainer.best_reg_B:
            resultado["puntuacion_B"] = float(trainer.best_reg_B.predict(X_input)[0])

        if verbose:
            self._mostrar_resultado(resultado)
        return resultado

    def _mostrar_resultado(self, res: dict[str, Any]) -> None:
        cfg     = self.cfg
        ganador = res["ganador"]
        emoji   = "⚽" if cfg.deporte == "futbol" else "🥊"

        titulo("PREDICCIÓN DEL ENFRENTAMIENTO", 50)
        print(f"\n  {emoji} {c('Resultado más probable:', 'bold')} {c(ganador, 'ok')}\n")
        print(f"  {'─' * 46}")
        print(f"  {'Resultado':<22}  {'Probabilidad':>10}  {'Barra':>14}")
        print(f"  {'─' * 46}")

        for etiqueta, prob in sorted(res["probabilidades"].items(), key=lambda x: -x[1]):
            barra  = "█" * int(prob * 20) + "░" * (20 - int(prob * 20))
            marca  = " ← " if etiqueta == ganador else "   "
            color  = "ok" if etiqueta == ganador else "reset"
            print(
                f"  {c(etiqueta, color):<22}  "
                f"{c(f'{prob * 100:>6.1f}%', color):>10}  "
                f"{barra}{marca}"
            )
        print(f"  {'─' * 46}")

        pa = res.get("puntuacion_A")
        pb = res.get("puntuacion_B")
        if pa is not None or pb is not None:
            print(f"\n  {c('Marcador esperado:', 'bold')}")
            if pa is not None and pb is not None:
                print(f"    {cfg.nombre_A}: {pa:.2f}  —  {cfg.nombre_B}: {pb:.2f}")
            elif pa is not None:
                print(f"    {cfg.nombre_A}: {pa:.2f}")
            else:
                print(f"    {cfg.nombre_B}: {pb:.2f}")

    # ── Interactive loop ───────────────────────────────────────────────────────

    def bucle_interactivo(self) -> None:
        """Repeat prediction until the user decides to stop."""
        while True:
            titulo("NUEVO ENFRENTAMIENTO", 50)
            try:
                self.predecir()
            except KeyboardInterrupt:
                break
            except Exception as exc:
                error(f"Error en la predicción: {exc}")
            print()
            if not confirmar("¿Predecir otro enfrentamiento?", default=True):
                break
