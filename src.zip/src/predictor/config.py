"""
config.py — Configuration data class for the sports match predictor.

``Config``
    Central store for every parameter that controls the predictor's
    behaviour, from feature column names to CV fold counts.
    Fully serializable to/from JSON for reproducible experiments.
"""

from __future__ import annotations

import json
from typing import Any

from .ui import ok


class Config:
    """All configuration for a single predictor run.

    Attributes:
        deporte:               Sport identifier, e.g. ``"futbol"`` or ``"combat"``.
        con_empate:            ``True`` if draws are a possible outcome.
        feat_names_A:          Feature names for competitor A (without the ``A_`` prefix).
        feat_names_B:          Feature names for competitor B (without the ``B_`` prefix).
        target_col:            Name of the outcome column in the CSV.
        label_A:               Value in *target_col* that means A won.
        label_E:               Value that means draw (``None`` when draws impossible).
        label_B:               Value that means B won.
        score_col_A:           CSV column with A's numeric score (``None`` if absent).
        score_col_B:           CSV column with B's numeric score (``None`` if absent).
        feature_engineering:   Auto-create ``DIFF_`` and ``RATIO_`` columns.
        usar_pesos_temporales: Weight recent matches more heavily.
        n_iter_search:         Iterations for ``RandomizedSearchCV``.
        cv_folds:              Folds for stratified cross-validation.
        nombre_A:              Display label for competitor A.
        nombre_B:              Display label for competitor B.
    """

    def __init__(self) -> None:
        self.deporte:               str              = "futbol"
        self.con_empate:            bool             = True
        self.feat_names_A:          list[str]        = []
        self.feat_names_B:          list[str]        = []
        self.target_col:            str              = "resultado"
        self.label_A:               str              = "A"
        self.label_E:               str | None       = "E"
        self.label_B:               str              = "B"
        self.score_col_A:           str | None       = None
        self.score_col_B:           str | None       = None
        self.feature_engineering:   bool             = True
        self.usar_pesos_temporales: bool             = False
        self.n_iter_search:         int              = 30
        self.cv_folds:              int              = 5
        self.nombre_A:              str              = "Equipo A"
        self.nombre_B:              str              = "Equipo B"

    # ── Serialization ──────────────────────────────────────────────────────────

    def to_dict(self) -> dict[str, Any]:
        """Return the full configuration as a plain dictionary."""
        return self.__dict__.copy()

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> Config:
        """Reconstruct a Config from a plain dictionary.

        Unknown keys are ignored so that old config files stay compatible
        with newer versions of the code.
        """
        cfg = cls()
        for k, v in d.items():
            if hasattr(cfg, k):
                setattr(cfg, k, v)
        return cfg

    def save(self, path: str) -> None:
        """Serialize configuration to a JSON file.

        Args:
            path: Output file path.
        """
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(self.to_dict(), fh, ensure_ascii=False, indent=2)
        ok(f"Configuración guardada en {path}")

    @classmethod
    def load(cls, path: str) -> Config:
        """Load configuration from a JSON file.

        Args:
            path: Path to an existing JSON config file.

        Returns:
            A fully populated :class:`Config` instance.
        """
        with open(path, "r", encoding="utf-8") as fh:
            return cls.from_dict(json.load(fh))
