"""
data.py — Data loading, preprocessing, and feature engineering.

``DataManager``
    Handles every data-related task: CSV loading with auto-separator
    detection, guided manual entry, null imputation, automatic feature
    engineering and construction of single-row prediction vectors.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from sklearn.impute import SimpleImputer

from .config import Config
from .constants import SEPARADORES_CSV
from .ui import error, info, ok, pedir, titulo, warn, c


class DataManager:
    """Load, validate, preprocess and engineer features for match data.

    Args:
        cfg: Predictor configuration that specifies feature names,
             target column labels, and pipeline flags.

    Attributes:
        cfg:          Bound :class:`~predictor.config.Config` instance.
        df_raw:       Original DataFrame before any transformation.
        df:           Processed DataFrame used for training/prediction.
        feature_cols: Ordered list of feature column names after engineering.
    """

    def __init__(self, cfg: Config) -> None:
        self.cfg          = cfg
        self.df_raw: pd.DataFrame | None = None
        self.df:    pd.DataFrame | None  = None
        self.feature_cols: list[str]     = []

    # ── Loading ────────────────────────────────────────────────────────────────

    def cargar_csv(self, path: str) -> pd.DataFrame:
        """Load a CSV, auto-detecting the delimiter.

        Tries each separator in :data:`~predictor.constants.SEPARADORES_CSV`
        and returns the first parse that yields more than one column.

        Args:
            path: Filesystem path to the CSV file.

        Returns:
            Raw :class:`pandas.DataFrame`.

        Raises:
            FileNotFoundError: When *path* does not exist.
            ValueError:        When no separator produces a valid parse.
        """
        p = Path(path)
        if not p.exists():
            raise FileNotFoundError(f"Archivo no encontrado: {p}")

        for sep in SEPARADORES_CSV:
            try:
                df = pd.read_csv(p, sep=sep, engine="python")
                if len(df.columns) > 1:
                    ok(f"CSV cargado con separador '{sep}' → {len(df)} filas, {len(df.columns)} columnas.")
                    return df
            except Exception:
                continue

        raise ValueError("No se pudo parsear el CSV con ningún separador conocido.")

    def cargar_manual(self, n_partidos: int) -> pd.DataFrame:
        """Collect historical match data entry by entry from stdin.

        Args:
            n_partidos: Number of matches to collect.

        Returns:
            DataFrame with one row per match.

        Raises:
            KeyboardInterrupt: When the user chooses to cancel mid-entry.
        """
        cfg = self.cfg
        labels_validos = [cfg.label_A, cfg.label_B]
        if cfg.con_empate and cfg.label_E:
            labels_validos.insert(1, cfg.label_E)

        registros: list[dict[str, Any]] = []
        i = 0
        while i < n_partidos:
            titulo(f"Enfrentamiento {i + 1}/{n_partidos}", 40)
            registro: dict[str, Any] = {}

            print(f"\n  {c('► Estadísticas de ' + cfg.nombre_A, 'ok')}")
            for feat in cfg.feat_names_A:
                while True:
                    try:
                        registro[f"A_{feat}"] = float(input(f"    {feat}: ").strip())
                        break
                    except ValueError:
                        error("Introduce un número válido.")

            print(f"\n  {c('► Estadísticas de ' + cfg.nombre_B, 'warn')}")
            for feat in cfg.feat_names_B:
                while True:
                    try:
                        registro[f"B_{feat}"] = float(input(f"    {feat}: ").strip())
                        break
                    except ValueError:
                        error("Introduce un número válido.")

            print(f"\n  Opciones de resultado: {c(' | '.join(labels_validos), 'bold')}")
            resultado = pedir("Resultado", str, opciones=labels_validos)
            registro[cfg.target_col] = resultado

            if cfg.score_col_A:
                registro[cfg.score_col_A] = pedir(
                    f"Puntuación de {cfg.nombre_A}", float
                )
            if cfg.score_col_B:
                registro[cfg.score_col_B] = pedir(
                    f"Puntuación de {cfg.nombre_B}", float
                )

            from .ui import separador
            separador()
            print(f"  Registro: {registro}")
            accion = pedir(
                "¿Confirmar (c), repetir (r) o cancelar todo (x)?",
                str, opciones=["c", "r", "x"], default="c",
            )
            if accion == "x":
                raise KeyboardInterrupt("Entrada cancelada por el usuario.")
            if accion == "r":
                continue
            registros.append(registro)
            i += 1

        return pd.DataFrame(registros)

    # ── Preprocessing ──────────────────────────────────────────────────────────

    def preparar(self, df: pd.DataFrame) -> None:
        """Run the full preprocessing and feature-engineering pipeline.

        Steps:

        1. Validate that all expected ``A_<feat>`` / ``B_<feat>`` columns exist.
        2. Impute missing values with the column median.
        3. Create ``DIFF_<feat>`` and ``RATIO_<feat>`` columns for every feature
           shared between A and B (when :attr:`~Config.feature_engineering` is
           ``True``).
        4. Record the final ordered list of feature column names.

        Args:
            df: Raw DataFrame from :meth:`cargar_csv` or :meth:`cargar_manual`.

        Raises:
            ValueError: When required columns are missing in *df*.
        """
        cfg = self.cfg
        self.df_raw = df.copy()

        todas_feats = (
            [f"A_{f}" for f in cfg.feat_names_A]
            + [f"B_{f}" for f in cfg.feat_names_B]
        )
        faltantes = [col for col in todas_feats if col not in df.columns]
        if faltantes:
            raise ValueError(
                f"Columnas no encontradas en el DataFrame: {faltantes}"
            )

        df = df.copy()

        # Impute nulls with median
        num_cols = [col for col in todas_feats if col in df.columns]
        nulos = df[num_cols].isnull().sum().sum()
        if nulos > 0:
            warn(f"Se encontraron {nulos} valores faltantes → imputados con la mediana.")
            imputer = SimpleImputer(strategy="median")
            df[num_cols] = imputer.fit_transform(df[num_cols])

        # Feature engineering: differences and ratios between A and B
        if cfg.feature_engineering:
            feats_comunes = [f for f in cfg.feat_names_A if f in cfg.feat_names_B]
            for feat in feats_comunes:
                ca, cb = f"A_{feat}", f"B_{feat}"
                if ca in df.columns and cb in df.columns:
                    df[f"DIFF_{feat}"]  = df[ca] - df[cb]
                    denom               = df[cb].replace(0, np.nan)
                    df[f"RATIO_{feat}"] = (df[ca] / denom).fillna(0)

        eng_cols = [
            col for col in df.columns
            if col.startswith("DIFF_") or col.startswith("RATIO_")
        ]
        self.feature_cols = todas_feats + eng_cols
        self.df = df
        info(f"Features totales tras preprocesamiento: {len(self.feature_cols)}")

    # ── Feature extraction ─────────────────────────────────────────────────────

    def get_X(self) -> pd.DataFrame:
        """Return the feature matrix ready for model training.

        Returns:
            DataFrame with shape ``(n_samples, n_features)``.
        """
        return self.df[self.feature_cols].copy()

    def get_y_class(self) -> pd.Series:
        """Return the classification target as integers.

        Mapping: ``label_A → 1``, ``label_B → 0``, ``label_E → 2``.

        Returns:
            Integer :class:`pandas.Series`.

        Raises:
            ValueError: When the target column contains unexpected labels.
        """
        cfg  = self.cfg
        mapa: dict[str, int] = {cfg.label_A: 1, cfg.label_B: 0}
        if cfg.con_empate and cfg.label_E:
            mapa[cfg.label_E] = 2
        y = self.df[cfg.target_col].map(mapa)
        if y.isnull().any():
            raise ValueError(
                f"Etiquetas no reconocidas: {self.df[cfg.target_col].unique()}. "
                "Configura label_A, label_E y label_B correctamente."
            )
        return y

    def get_y_score(self, col: str) -> pd.Series | None:
        """Return a numeric score column if it exists in the DataFrame.

        Args:
            col: Column name to look up.

        Returns:
            Float :class:`pandas.Series` or ``None`` when absent.
        """
        if col and col in self.df.columns:
            return self.df[col].astype(float)
        return None

    def get_pesos(self) -> np.ndarray | None:
        """Generate linear temporal weights (most recent = highest weight).

        Returns ``None`` when :attr:`~Config.usar_pesos_temporales` is ``False``.
        """
        if not self.cfg.usar_pesos_temporales:
            return None
        n     = len(self.df)
        pesos = np.linspace(0.5, 1.0, n)
        return pesos / pesos.sum() * n

    def construir_vector_prediccion(
        self,
        stats_A: dict[str, float],
        stats_B: dict[str, float],
    ) -> pd.DataFrame:
        """Build a single-row DataFrame from two competitors' stats.

        Applies the same feature-engineering transformations used during
        training so the prediction vector is aligned with the trained model.

        Args:
            stats_A: Feature-name → value mapping for competitor A.
            stats_B: Feature-name → value mapping for competitor B.

        Returns:
            One-row :class:`pandas.DataFrame` with columns matching
            :attr:`feature_cols`.
        """
        cfg = self.cfg
        row: dict[str, float] = {}
        for f in cfg.feat_names_A:
            row[f"A_{f}"] = stats_A.get(f, 0.0)
        for f in cfg.feat_names_B:
            row[f"B_{f}"] = stats_B.get(f, 0.0)

        if cfg.feature_engineering:
            for feat in [f for f in cfg.feat_names_A if f in cfg.feat_names_B]:
                a_val = row.get(f"A_{feat}", 0.0)
                b_val = row.get(f"B_{feat}", 0.0)
                row[f"DIFF_{feat}"]  = a_val - b_val
                row[f"RATIO_{feat}"] = a_val / b_val if b_val != 0 else 0.0

        df_row = pd.DataFrame([row])
        for col in self.feature_cols:
            if col not in df_row.columns:
                df_row[col] = 0.0
        return df_row[self.feature_cols]
