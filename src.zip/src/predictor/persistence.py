"""
persistence.py — Save and restore a trained predictor bundle.

``ModelStore``
    Serializes the full predictor state — config, trained models, and data
    manager metadata — to a single ``.pkl`` file with ``joblib``.  Loading
    restores everything needed for prediction without retraining.
"""

from __future__ import annotations

import joblib
import pandas as pd

from .config import Config
from .data import DataManager
from .trainer import ModelTrainer
from .ui import ok, info


class ModelStore:
    """Persist and restore a trained predictor bundle.

    The bundle written to disk contains:

    - ``cfg``            — :class:`~predictor.config.Config` as a plain dict.
    - ``best_clf``       — Trained sklearn classifier.
    - ``best_reg_A``     — Trained regressor for A (or ``None``).
    - ``best_reg_B``     — Trained regressor for B (or ``None``).
    - ``feature_cols``   — Ordered list of feature column names.
    - ``label_names``    — Human-readable class labels.
    - ``class_values``   — Sorted list of integer class values.
    - ``dm_feature_cols``— Feature columns stored in the DataManager.
    - ``clf_report``     — CV classification metrics.
    - ``reg_report``     — CV regression metrics.
    """

    @staticmethod
    def guardar(
        path: str,
        cfg: Config,
        trainer: ModelTrainer,
        data_mgr: DataManager,
    ) -> None:
        """Serialize the predictor bundle to *path*.

        Args:
            path:     Output file path (e.g. ``"modelo.pkl"``).
            cfg:      Configuration to save.
            trainer:  Trained :class:`~predictor.trainer.ModelTrainer`.
            data_mgr: Prepared :class:`~predictor.data.DataManager`.
        """
        bundle = {
            "cfg":             cfg.to_dict(),
            "best_clf":        trainer.best_clf,
            "best_reg_A":      trainer.best_reg_A,
            "best_reg_B":      trainer.best_reg_B,
            "feature_cols":    trainer.feature_cols,
            "label_names":     trainer.label_names,
            "class_values":    trainer.class_values,
            "dm_feature_cols": data_mgr.feature_cols,
            "clf_report":      trainer.clf_report,
            "reg_report":      trainer.reg_report,
        }
        joblib.dump(bundle, path)
        ok(f"Modelo guardado en '{path}'.")

    @staticmethod
    def cargar(path: str) -> tuple[Config, ModelTrainer, DataManager]:
        """Restore a predictor bundle from *path*.

        Args:
            path: Path to an existing ``.pkl`` bundle.

        Returns:
            A tuple ``(cfg, trainer, data_mgr)`` ready for prediction.

        Raises:
            FileNotFoundError: When *path* does not exist.
            KeyError:          When the bundle is missing expected keys.
        """
        info(f"Cargando modelo desde '{path}'...")
        bundle = joblib.load(path)

        cfg = Config.from_dict(bundle["cfg"])

        trainer               = ModelTrainer(cfg)
        trainer.best_clf      = bundle["best_clf"]
        trainer.best_reg_A    = bundle.get("best_reg_A")
        trainer.best_reg_B    = bundle.get("best_reg_B")
        trainer.feature_cols  = bundle["feature_cols"]
        trainer.label_names   = bundle["label_names"]
        trainer.class_values  = bundle["class_values"]
        trainer.clf_report    = bundle.get("clf_report", {})
        trainer.reg_report    = bundle.get("reg_report", {})

        # Reconstruct a minimal DataManager (no training data needed for prediction)
        data_mgr              = DataManager(cfg)
        data_mgr.feature_cols = bundle["dm_feature_cols"]
        data_mgr.df           = pd.DataFrame(columns=data_mgr.feature_cols)

        ok("Modelo cargado correctamente.")
        return cfg, trainer, data_mgr
