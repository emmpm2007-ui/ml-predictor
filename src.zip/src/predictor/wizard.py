"""
wizard.py — Interactive configuration and data-loading assistants.

Functions here guide a first-time user through the full setup without
needing a pre-existing CSV or JSON config file.
"""

from __future__ import annotations

from pathlib import Path

import pandas as pd

from .config import Config
from .constants import SUGERENCIAS
from .ui import c, confirmar, error, info, ok, pedir, separador, titulo, warn


# ── Configuration wizard ───────────────────────────────────────────────────────

def configurar_interactivo() -> Config:
    """Guide the user through full predictor configuration.

    Covers: sport type, competitor names, draw flag, feature names,
    outcome labels, optional score columns, and advanced options.

    Returns:
        A fully populated :class:`~predictor.config.Config` instance.
    """
    titulo("ASISTENTE DE CONFIGURACIÓN")
    cfg = Config()

    # Sport
    info("Deportes sugeridos: " + ", ".join(SUGERENCIAS.keys()))
    cfg.deporte = pedir("Deporte (futbol / combat / otro)", str, default="futbol")

    # Competitor names
    cfg.nombre_A = pedir("Nombre del competidor A", str, default="Equipo A")
    cfg.nombre_B = pedir("Nombre del competidor B", str, default="Equipo B")

    # Draw flag
    cfg.con_empate = confirmar("¿Es posible el empate?", default=True)

    # Outcome labels
    separador()
    info("Define las etiquetas de resultado tal como aparecen en tu CSV.")
    cfg.label_A = pedir(f"Etiqueta cuando gana {cfg.nombre_A}", str, default="A")
    cfg.label_B = pedir(f"Etiqueta cuando gana {cfg.nombre_B}", str, default="B")
    if cfg.con_empate:
        cfg.label_E = pedir("Etiqueta de empate", str, default="E")
    else:
        cfg.label_E = None

    cfg.target_col = pedir("Nombre de la columna de resultado en el CSV", str, default="resultado")

    # Features
    separador()
    sugs = SUGERENCIAS.get(cfg.deporte, SUGERENCIAS.get("futbol", []))
    if sugs:
        info("Features sugeridas para " + cfg.deporte + ":")
        for i, s in enumerate(sugs, 1):
            print(f"    {i:>2}. {s}")
        usar_sugs = confirmar("¿Usar estas features como punto de partida?", default=True)
        if usar_sugs:
            cfg.feat_names_A = sugs[:]
            cfg.feat_names_B = sugs[:]
            ok(f"{len(sugs)} features cargadas.")

    if not cfg.feat_names_A:
        info("Introduce las features separadas por comas.")
        raw = pedir("Features (ej: goles,posesion,tiros)", str)
        feats = [f.strip() for f in raw.split(",") if f.strip()]
        cfg.feat_names_A = feats
        cfg.feat_names_B = feats

    # Optional score columns
    separador()
    if confirmar("¿Tu CSV tiene columnas de puntuación numérica?", default=False):
        cfg.score_col_A = pedir(
            f"Columna de puntuación de {cfg.nombre_A} en el CSV", str, allow_blank=True
        ) or None
        cfg.score_col_B = pedir(
            f"Columna de puntuación de {cfg.nombre_B} en el CSV", str, allow_blank=True
        ) or None

    # Advanced options
    separador()
    if confirmar("¿Configurar opciones avanzadas?", default=False):
        cfg.feature_engineering   = confirmar("¿Crear features DIFF_ y RATIO_?", default=True)
        cfg.usar_pesos_temporales = confirmar("¿Dar más peso a los partidos recientes?", default=False)
        cfg.cv_folds    = pedir("Número de folds CV", int, default=5)
        cfg.n_iter_search = pedir("Iteraciones de búsqueda de hiperparámetros", int, default=30)

    ok("Configuración completada.")
    return cfg


# ── Data-loading wizard ────────────────────────────────────────────────────────

def cargar_datos_interactivo(cfg: Config) -> pd.DataFrame:
    """Let the user choose between loading a CSV or entering data manually.

    Args:
        cfg: Bound configuration (needed for column names and labels).

    Returns:
        Raw :class:`pandas.DataFrame` with historical match records.
    """
    from .data import DataManager

    titulo("CARGA DE DATOS HISTÓRICOS")
    info("Opciones:")
    print("    1. Cargar desde CSV")
    print("    2. Introducir datos manualmente")
    opcion = pedir("Elige 1 o 2", str, opciones=["1", "2"], default="1")

    dm = DataManager(cfg)

    if opcion == "1":
        while True:
            ruta = pedir("Ruta al archivo CSV", str)
            try:
                df = dm.cargar_csv(ruta)
                _verificar_columnas_csv(df, cfg)
                return df
            except (FileNotFoundError, ValueError) as exc:
                error(str(exc))
                if not confirmar("¿Intentar con otra ruta?", default=True):
                    raise
    else:
        n = pedir("¿Cuántos enfrentamientos históricos vas a introducir?", int, default=10)
        return dm.cargar_manual(n)


def _verificar_columnas_csv(df: pd.DataFrame, cfg: Config) -> None:
    """Warn about missing expected columns without raising.

    Args:
        df:  DataFrame to inspect.
        cfg: Configuration that specifies expected column names.
    """
    esperadas = (
        [f"A_{f}" for f in cfg.feat_names_A]
        + [f"B_{f}" for f in cfg.feat_names_B]
        + [cfg.target_col]
    )
    faltantes = [c for c in esperadas if c not in df.columns]
    if faltantes:
        warn(f"Columnas no encontradas en el CSV: {faltantes}")
        warn("Verifica que los nombres de features coincidan exactamente.")
    else:
        ok("Todas las columnas esperadas están presentes.")
