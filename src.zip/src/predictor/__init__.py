"""
predictor — Sports match prediction engine package.

Convenience re-exports::

    from src.predictor import Config, DataManager, ModelTrainer, Predictor
"""

from .config import Config
from .data import DataManager
from .trainer import ModelTrainer
from .predictor import Predictor

__all__ = ["Config", "DataManager", "ModelTrainer", "Predictor"]
__version__ = "1.0.0"
